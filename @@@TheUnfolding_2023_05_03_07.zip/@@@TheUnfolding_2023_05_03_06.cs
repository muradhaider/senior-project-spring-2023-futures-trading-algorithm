#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class TheUnfolding_2023_05_03_06 : Strategy
	{
		private DEMA DEMA1;
		private VMA VMA1;
		private TEMA TEMA1;
		private EMA EMA1; 
		//private ATRTrailingStop atrTrailingStop;
        private bool exitLong;
        private bool exitShort;
		private bool TargetBooked;
		private double AccumulatedProfit;
		private double stopLong;
		private double stopShort;


		

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "TheUnfolding_2023_05_03_06";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				Start										= DateTime.Parse("05:00", System.Globalization.CultureInfo.InvariantCulture);
				End											= DateTime.Parse("13:00", System.Globalization.CultureInfo.InvariantCulture);
				DailyProfit									= 1200;
				TargetBooked								= true;
				AccumulatedProfit							= 0;
				
		
			}
			else if (State == State.Configure)
			{
				SetProfitTarget(@"boom", CalculationMode.Ticks, 12);
			}
			else if (State == State.DataLoaded)
			{				
				DEMA1				= DEMA(Close, 9);
				VMA1				= VMA(Close, 9, 9);
				TEMA1				= TEMA(Close, 9);
				EMA1 				= EMA(Close, 9);
				
                
				//atrTrailingStop = ATRTrailingStop(2, 1.00);
				//stopLoss = Low[1] - 2 * TickSize;
				//stopLoss2 = High[1] + 2 * TickSize;
				
				DEMA1.Plots[0].Brush = Brushes.Goldenrod;
				VMA1.Plots[0].Brush = Brushes.DodgerBlue;
				TEMA1.Plots[0].Brush = Brushes.Goldenrod;
				EMA1.Plots[0].Brush = Brushes.Goldenrod;
				
				AddChartIndicator(DEMA1);
				AddChartIndicator(VMA1);
				AddChartIndicator(TEMA1);
				AddChartIndicator(EMA1);
				//AddChartIndicator(atrTrailingStop);
			}
		}
		
		

		protected override void OnBarUpdate()
		{
			//double atrValue = atrTrailingStop.Value[0];
			//double stopLossPrice = stopLoss;
			//double stopLossPrice2 = stopLoss2;
			

    if (BarsInProgress != 0)
        return;

    if (CurrentBars[0] < BarsRequiredToTrade)
        return;
	
	stopLong = Low[1]; 
	stopShort = High[1];
	
	
	if ((Times[0][0].TimeOfDay >= Start.TimeOfDay)
				 && (Times[0][0].TimeOfDay < End.TimeOfDay))
			{
				BackBrush = Brushes.SaddleBrown;
			}
			
    //bool exitLong = Close[0] <= atrValue;
	bool exitLong = Close[0] < stopLong;
	//bool exitLong = CurrentBar <= stopLossPrice;

    if (Position.MarketPosition == MarketPosition.Long)
    {
        if (exitLong)
        {
            ExitLong(Convert.ToInt32(DefaultQuantity), @"stop", @"boom");
            exitLong = false;
        }
    }

    //bool exitShort = Close[0] >= atrValue;
	bool exitShort = Close[0] >= stopShort;
	//bool exitShort = CurrentBar >= stopLossPrice2;

    if (Position.MarketPosition == MarketPosition.Short)
    {
        if (exitShort)
        {
            ExitShort(Convert.ToInt32(DefaultQuantity), @"stop", @"boom");
			exitShort = false;
        }
    }
		//set 1
	if (Position.MarketPosition == MarketPosition.Flat && IsFirstTickOfBar) {
			if ((CrossAbove(DEMA1, VMA1, 3))
				 && (CrossAbove(TEMA1, VMA1, 3))
				 && (CrossAbove(EMA1, VMA1, 3))
				 &&((Times[0][0].TimeOfDay >= Start.TimeOfDay)
				 && (Times[0][0].TimeOfDay < End.TimeOfDay))
				 && (TargetBooked == true))
			{
				EnterLong(Convert.ToInt32(DefaultQuantity), @"boom");
			}
	}
			// Set 2
			if (Position.MarketPosition == MarketPosition.Flat && IsFirstTickOfBar){
			 	if ((CrossBelow(DEMA1, VMA1, 3))
				 && (CrossBelow(TEMA1, VMA1, 3))
				 && (CrossBelow(EMA1, VMA1, 3))
				 &&((Times[0][0].TimeOfDay >= Start.TimeOfDay)
				 && (Times[0][0].TimeOfDay < End.TimeOfDay))
				 && (TargetBooked == true))
			{
				EnterShort(Convert.ToInt32(DefaultQuantity), @"boom");
			}
			
	}
	
	 // Set 3
			if (SystemPerformance.AllTrades.TradesPerformance.Currency.CumProfit - AccumulatedProfit >= DailyProfit)
			{
				TargetBooked = false;
			}
			
			 // Set 4
			if (Times[0][0].TimeOfDay < Times[0][1].TimeOfDay)
			{
				TargetBooked = true;
				AccumulatedProfit = SystemPerformance.AllTrades.TradesPerformance.Currency.CumProfit;
			}
			
		}
		
		#region Properties
		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="Start", Order=1, GroupName="Parameters")]
		public DateTime Start
		{ get; set; }

		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="End", Order=2, GroupName="Parameters")]
		public DateTime End
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="DailyProfit", Order=1, GroupName="Parameters")]
		public double DailyProfit
		{ get; set; }
		#endregion
	}
}
